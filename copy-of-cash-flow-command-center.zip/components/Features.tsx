import React from 'react';
import { FEATURES } from '../constants';
import { CheckCircle2 } from 'lucide-react';

const Features: React.FC = () => {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ✅ Introducing: Cash Flow Command Center
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A specialized Notion template designed to give you complete control over your restaurant's finances in minutes.
          </p>
        </div>

        <div className="space-y-24">
          {FEATURES.map((feature, index) => {
            const isEven = index % 2 === 0;
            const Icon = feature.icon;
            
            return (
              <div key={feature.id} className={`flex flex-col lg:flex-row items-center gap-12 lg:gap-20 ${!isEven ? 'lg:flex-row-reverse' : ''}`}>
                
                {/* Text Content */}
                <div className="flex-1 space-y-6">
                  <div className="inline-flex items-center justify-center p-3 bg-indigo-100 rounded-lg text-primary mb-2">
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 leading-tight">
                    {feature.title}
                  </h3>
                  <p className="text-lg text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                  <ul className="space-y-4 pt-4">
                    {feature.bullets.map((bullet, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle2 className="w-5 h-5 text-success mt-1 mr-3 flex-shrink-0" />
                        <span className="text-gray-700 font-medium">{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Visual Content */}
                <div className="flex-1 w-full">
                  <div className={`relative rounded-2xl bg-gray-50 p-2 border border-gray-200 shadow-2xl transform hover:scale-[1.01] transition-transform duration-500 ${isEven ? 'rotate-1' : '-rotate-1'}`}>
                    {/* Glass sheen effect */}
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 pointer-events-none z-10 rounded-xl"></div>
                    
                    {/* Browser-like Header for Product Screenshots */}
                    <div className="bg-white border-b border-gray-200 h-6 rounded-t-lg flex items-center px-3 space-x-1.5 mb-1">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                    </div>

                    <img 
                      src={feature.image}
                      alt={feature.imageAlt}
                      className="rounded-b-lg w-full h-auto object-cover shadow-sm bg-white"
                      loading="lazy"
                    />
                    
                    {/* Decorative Elements */}
                    <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-dots opacity-20 z-0"></div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
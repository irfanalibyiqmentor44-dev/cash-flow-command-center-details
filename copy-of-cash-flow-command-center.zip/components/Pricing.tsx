import React from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { GUMROAD_LINK } from '../constants';

const Pricing: React.FC = () => {
  return (
    <section className="py-24 bg-dark text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            🔥 Get Complete Cash Flow Clarity Today
          </h2>
          <p className="text-gray-400 text-xl">
            Stop guessing. Start knowing.
          </p>
        </div>

        <div className="max-w-md mx-auto bg-gray-800 rounded-3xl shadow-2xl overflow-hidden border border-gray-700 hover:border-accent/50 transition-colors duration-300">
          <div className="p-8 sm:p-12 text-center">
            <p className="text-accent font-semibold uppercase tracking-wider text-sm mb-4">
              Lifetime Access
            </p>
            <div className="flex justify-center items-baseline mb-2">
              <span className="text-5xl sm:text-7xl font-extrabold text-white">$97</span>
              <span className="text-xl text-gray-400 ml-2">USD</span>
            </div>
            <p className="text-gray-400 mb-8 text-sm">One-time payment • No monthly fees</p>
            
            <a
              href={GUMROAD_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex justify-center items-center px-6 py-4 border border-transparent text-lg font-bold rounded-xl text-dark bg-accent hover:bg-yellow-400 transform hover:-translate-y-1 transition-all shadow-lg hover:shadow-accent/50 mb-8"
            >
              Get Instant Access Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </a>

            <div className="space-y-4 text-left">
              {[
                "Instant Download",
                "Full Notion Template",
                "Works on Free Notion Plan",
                "30-Day Guarantee",
                "Video Setup Guide",
                "Mobile Friendly"
              ].map((item, i) => (
                <div key={i} className="flex items-center text-gray-300">
                  <Check className="w-5 h-5 text-success mr-3 flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-gray-700/50 p-4 text-center">
            <p className="text-sm text-gray-400">
              Secure payment via Gumroad 🔒
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
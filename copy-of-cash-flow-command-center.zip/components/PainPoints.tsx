import React from 'react';
import { PAIN_POINTS } from '../constants';

const PainPoints: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ❌ Sound Familiar?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Running a restaurant is hard enough without worrying about where every dollar is going.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PAIN_POINTS.map((point) => (
            <div key={point.id} className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-red-500 hover:-translate-y-1 transition-transform duration-300">
              <div className="text-4xl mb-4">{point.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{point.title}</h3>
              <p className="text-gray-600 leading-relaxed">
                "{point.description}"
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-yellow-50 border border-accent/20 rounded-2xl p-8 text-center max-w-4xl mx-auto">
          <p className="text-lg md:text-xl font-medium text-gray-800">
            <span className="text-red-600 font-bold">82%</span> of restaurant owners struggle with cash flow visibility, and <span className="text-red-600 font-bold">29%</span> run out of money before they even break even. Don't be a statistic.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PainPoints;
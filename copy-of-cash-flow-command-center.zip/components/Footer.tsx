import React from 'react';
import { SUPPORT_EMAIL } from '../constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-100 py-12 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-8">
          <span className="text-2xl font-bold text-gray-800">
            Cash Flow Command Center
          </span>
        </div>
        
        <p className="text-gray-500 mb-6">
          Questions? Email us at <a href={`mailto:${SUPPORT_EMAIL}`} className="text-primary hover:underline">{SUPPORT_EMAIL}</a>
        </p>
        
        <div className="text-sm text-gray-400">
          <p>© {currentYear} Cash Flow Command Center. All rights reserved.</p>
          <p className="mt-2">Not affiliated with Notion.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
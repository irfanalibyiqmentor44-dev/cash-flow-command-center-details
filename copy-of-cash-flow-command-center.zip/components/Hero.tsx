import React from 'react';
import { ChevronRight, ShieldCheck } from 'lucide-react';
import { GUMROAD_LINK } from '../constants';

const Hero: React.FC = () => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-primary via-secondary to-purple-900 pt-24 pb-16 lg:pt-32 lg:pb-24">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
        
        {/* Badge */}
        <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-white/10 border border-white/20 text-white mb-8 backdrop-blur-sm">
          <span className="text-accent mr-2">★</span>
          <span className="text-sm font-medium">Trusted by restaurant owners worldwide</span>
        </div>

        {/* Headlines */}
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white tracking-tight mb-6 leading-tight">
          Stop Running Out of Money.<br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-accent">
            Know Your Cash Flow in 5 Minutes.
          </span>
        </h1>
        
        <p className="max-w-2xl text-xl text-purple-100 mb-10">
          Complete financial clarity for your restaurant without the expensive $200/month accounting software.
        </p>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-4 w-full justify-center items-center">
          <a
            href={GUMROAD_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full sm:w-auto inline-flex justify-center items-center px-8 py-4 border border-transparent text-lg font-bold rounded-full text-primary bg-white hover:bg-gray-50 transform hover:-translate-y-1 transition-all shadow-xl hover:shadow-2xl"
          >
            Get Instant Access Now
            <ChevronRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Trust/Guarantee text */}
        <div className="mt-8 flex flex-col sm:flex-row items-center text-sm text-purple-200 gap-4 sm:gap-8">
          <div className="flex items-center">
            <ShieldCheck className="w-4 h-4 mr-1 text-success" />
            <span>30-Day Money-Back Guarantee</span>
          </div>
          <div className="flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-accent mr-2"></span>
            <span>$97 One-time Payment</span>
          </div>
          <div className="flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-accent mr-2"></span>
            <span>Lifetime Access</span>
          </div>
        </div>

        {/* Visual Preview Placeholder - Representing the Dashboard */}
        <div className="mt-16 relative w-full max-w-5xl">
            <div className="absolute inset-0 bg-accent blur-3xl opacity-20 rounded-full transform translate-y-10"></div>
            <div className="relative rounded-xl border border-white/20 shadow-2xl overflow-hidden glass-card">
                 {/* Browser Chrome */}
                <div className="bg-gray-100 border-b border-gray-200 h-8 flex items-center px-4 space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                    <div className="w-3 h-3 rounded-full bg-green-400"></div>
                </div>
                {/* Content Image */}
                <img 
                    src="https://picsum.photos/1200/600?grayscale" 
                    alt="Cash Flow Command Center Dashboard Mockup" 
                    className="w-full h-auto object-cover"
                />
                 {/* Floating Highlight Card */}
                <div className="absolute bottom-4 right-4 sm:bottom-10 sm:right-10 bg-white p-4 rounded-lg shadow-xl border-l-4 border-success max-w-xs text-left animate-bounce hidden md:block">
                    <p className="text-xs text-gray-500 font-semibold uppercase">Current Cash Position</p>
                    <p className="text-2xl font-bold text-gray-900">$42,500.00</p>
                    <p className="text-sm text-success flex items-center mt-1">
                        <span className="mr-1">●</span> Status: SAFE
                    </p>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Hero;
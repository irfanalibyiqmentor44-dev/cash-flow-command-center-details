import React from 'react';
import { ShieldCheck } from 'lucide-react';

const Guarantee: React.FC = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-emerald-500 to-teal-600 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full mix-blend-overlay filter blur-3xl transform -translate-x-1/2 -translate-y-1/2"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full mix-blend-overlay filter blur-3xl transform translate-x-1/2 translate-y-1/2"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="inline-flex items-center justify-center p-4 bg-white/20 rounded-full mb-8 backdrop-blur-md">
          <ShieldCheck className="w-12 h-12 text-white" />
        </div>
        
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          🛡️ Zero-Risk 30-Day Guarantee
        </h2>
        
        <div className="text-xl md:text-2xl text-emerald-50 mb-8 font-light">
          Try it for 30 days. If it doesn't save you at least 10 hours OR $500, simply email us for a full refund.
        </div>
        
        <p className="text-lg mb-8 opacity-90">
          No questions asked. No hard feelings. You literally cannot lose.
        </p>

        <div className="inline-block bg-white text-emerald-600 px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide shadow-lg">
          100% Money Back Guarantee
        </div>
      </div>
    </section>
  );
};

export default Guarantee;
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Features from './components/Features';
import Benefits from './components/Benefits';
import Guarantee from './components/Guarantee';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

function App() {
  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 antialiased selection:bg-purple-200 selection:text-primary">
      <Navbar />
      <main>
        <Hero />
        <PainPoints />
        <Features />
        <Benefits />
        <Guarantee />
        <Pricing />
        <FAQ />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}

export default App;
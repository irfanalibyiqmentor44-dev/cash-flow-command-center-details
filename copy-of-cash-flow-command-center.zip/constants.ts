import { 
  LayoutDashboard, 
  Wallet, 
  Receipt, 
  TrendingUp, 
  Gamepad2 
} from 'lucide-react';
import { Feature, PainPoint, Benefit, FAQItem } from './types';

export const GUMROAD_LINK = "https://irfanmentor.gumroad.com/l/jjwjx";
export const SUPPORT_EMAIL = "imentor923@gmail.com";

export const PAIN_POINTS: PainPoint[] = [
  {
    id: 'anxiety',
    title: "Cash Anxiety",
    description: "I have no idea if I'll have enough cash for rent next month.",
    icon: "💸"
  },
  {
    id: 'spreadsheet',
    title: "Spreadsheet Hell",
    description: "I'm drowning in Excel files but can't see the big picture.",
    icon: "📊"
  },
  {
    id: 'food-cost',
    title: "Food Cost Chaos",
    description: "My food costs are eating all my profit and I don't know why.",
    icon: "🍕"
  },
  {
    id: 'software',
    title: "Software Overload",
    description: "QuickBooks costs $200/month and I barely use 5% of it.",
    icon: "💰"
  }
];

// NOTE: Replace these placeholder URLs with your actual local file paths 
// (e.g., "/assets/dashboard.png") when you deploy.
export const FEATURES: Feature[] = [
  {
    id: 'dashboard',
    title: "Your Financial Control Room",
    description: "See your complete cash position at a glance without digging through reports.",
    bullets: [
      "Total cash balance updated in real-time",
      "This week's income vs expenses breakdown",
      "Color-coded safety alerts",
      "\"Days Until $0\" calculator",
      "5-minute weekly update workflow"
    ],
    // IMAGE 1 - Dashboard Screenshot
    image: "https://placehold.co/1200x800/f3f4f6/667eea?text=IMAGE+1:+Dashboard+Screenshot", 
    imageAlt: "Dashboard screenshot showing cash balance and status",
    icon: LayoutDashboard
  },
  {
    id: 'income',
    title: "Track Every Dollar Coming In",
    description: "Know exactly where your revenue comes from across all branches and channels.",
    bullets: [
      "Track by location (Branch A, B, C)",
      "Separate by customer type (Dine-in, Takeaway)",
      "Monitor individual income streams",
      "Expected vs actual revenue tracking",
      "Monthly calendar view of cash inflows"
    ],
    // IMAGE 2 - Income Tracker Screenshot
    image: "https://placehold.co/1200x800/f3f4f6/667eea?text=IMAGE+2:+Income+Tracker",
    imageAlt: "Income tracker table with branch breakdown",
    icon: Wallet
  },
  {
    id: 'expenses',
    title: "Smart Expense Management",
    description: "Pre-loaded with 20+ restaurant-specific categories to categorize spending instantly.",
    bullets: [
      "Labor cost tracking per branch",
      "Food & beverage cost separation",
      "Utilities, rent, and maintenance logs",
      "Payment method tracking",
      "Vendor management database"
    ],
    // IMAGE 3 - Expense Tracker Screenshot
    image: "https://placehold.co/1200x800/f3f4f6/667eea?text=IMAGE+3:+Expense+Tracker",
    imageAlt: "Expense tracker showing categories and amounts",
    icon: Receipt
  },
  {
    id: 'forecast',
    title: "90-Day Cash Forecasting",
    description: "Answer the most important question: Will I run out of money?",
    bullets: [
      "Week-by-week cash flow projections",
      "Starting balance + expected income logic",
      "Automatic deduction of expected expenses",
      "Visual trend analysis",
      "Prevents cash crunches before they happen"
    ],
    // IMAGE 4 - Forecast Screenshot
    image: "https://placehold.co/1200x800/f3f4f6/667eea?text=IMAGE+4:+Forecast+Screenshot",
    imageAlt: "Forecasting chart showing cash trends",
    icon: TrendingUp
  },
  {
    id: 'scenarios',
    title: "Test Before You Commit",
    description: "Make smarter decisions with scenario planning before spending real money.",
    bullets: [
      "Simulate equipment failure impacts",
      "Plan for food cost increases",
      "Prepare for seasonal revenue drops",
      "Sort scenarios by risk level",
      "Timeline view for strategic planning"
    ],
    // IMAGE 5 - Scenario Planner Screenshot
    image: "https://placehold.co/1200x800/f3f4f6/667eea?text=IMAGE+5:+Scenario+Planner",
    imageAlt: "Scenario planner interface",
    icon: Gamepad2
  }
];

export const BENEFITS: Benefit[] = [
  {
    id: 'time',
    title: "Get Your Time Back",
    description: "Before: 3-4 hours weekly. After: 10 minutes. That's 12-15 hours saved monthly.",
    icon: "⏰"
  },
  {
    id: 'money',
    title: "Save Real Money",
    description: "10-15% expense reduction typically saves $1,500-$3,000/month.",
    icon: "💰"
  },
  {
    id: 'decisions',
    title: "Better Decisions",
    description: "No surprise cash shortages. Make hiring and purchasing decisions with confidence.",
    icon: "🎯"
  },
  {
    id: 'mobile',
    title: "Works Everywhere",
    description: "Desktop, mobile, tablet. Share with your team or accountant easily.",
    icon: "📱"
  },
  {
    id: 'bonus',
    title: "Bonus Materials",
    description: "Includes video walkthrough, setup guide, and 20 pre-loaded categories.",
    icon: "🎁"
  },
  {
    id: 'subscription',
    title: "No Subscriptions",
    description: "One-time payment, lifetime access, free updates. No monthly fees.",
    icon: "🆓"
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "Do I need Notion experience?",
    answer: "Nope! A 15-minute video tutorial is included that walks you through everything step-by-step."
  },
  {
    question: "Will this work for a cafe or food truck?",
    answer: "Yes! It works for any food service business including cafes, food trucks, ghost kitchens, and fine dining."
  },
  {
    question: "I have multiple locations. Can I use this?",
    answer: "Perfect! It is specifically built for multi-location tracking with branch-specific tagging."
  },
  {
    question: "How is this different from QuickBooks?",
    answer: "QuickBooks is a $200/month full accounting suite. This is a specialized tool for cash flow management and clarity for a one-time fee of $97."
  },
  {
    question: "Do I need to pay for Notion?",
    answer: "No! The free plan of Notion works perfectly with this template."
  },
  {
    question: "Can I share this with my accountant?",
    answer: "Yes! You can invite them to your Notion page or export data to PDF/Excel."
  },
  {
    question: "I'm not tech-savvy. Is this hard to setup?",
    answer: "It takes about 15 minutes to set up. If you can send an email, you can use this template."
  },
  {
    question: "What exactly is included?",
    answer: "You get the Notion template, PDF setup guide, video walkthrough, launch checklist, scenario planner, and lifetime updates."
  }
];
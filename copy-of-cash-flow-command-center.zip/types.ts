import { LucideIcon } from 'lucide-react';

export interface Feature {
  id: string;
  title: string;
  description: string;
  bullets: string[];
  image: string; // URL/Path to the screenshot
  imageAlt: string;
  icon: LucideIcon;
}

export interface PainPoint {
  id: string;
  title: string;
  description: string;
  icon: string; // Emoji
}

export interface Benefit {
  id: string;
  title: string;
  description: string;
  icon: string; // Emoji
}

export interface FAQItem {
  question: string;
  answer: string;
}